## 1. Introduction ##




## 2. Pandas, Scatter Plots ##




## 3. Pandas, Histograms ##




## 4. Pandas, Scatter Matrix Plot ##




## 5. Pandas, Bar Plots ##




## 6. Next steps ##


